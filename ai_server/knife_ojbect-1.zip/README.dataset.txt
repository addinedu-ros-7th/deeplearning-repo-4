# knife-dataset-new > version-1-with out background-
https://universe.roboflow.com/workspace-zqssx/knife-dataset-new

Provided by a Roboflow user
License: CC BY 4.0

